`timescale 1ns/1ps

module tb_multiplier;

  reg clk;
  reg reset;
  reg start;

  reg signed [31:0] multiplicand;
  reg signed [31:0] multiplier;

  wire signed [63:0] product;
  wire done;

  integer pass_count;
  integer fail_count;

  shift_add_multiplier_fsm uut (
    .clk(clk),
    .reset(reset),
    .start(start),
    .multiplicand(multiplicand),
    .multiplier(multiplier),
    .product(product),
    .done(done)
  );

  initial clk = 0;
  always #5 clk = ~clk;

  initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0, tb_multiplier);
  end

  task run_test;
    input signed [31:0] A;
    input signed [31:0] B;
    input signed [63:0] expected;
    input integer test_num;
    begin
      multiplicand = A;
      multiplier   = B;

      @(posedge clk);
      start = 1;
      @(posedge clk);
      start = 0;

      wait(done);
      @(posedge clk);

      if (product === expected) begin
        $display("PASS  TC%0d: %0d * %0d = %0d",
                  test_num, A, B, product);
        pass_count = pass_count + 1;
      end else begin
        $display("FAIL  TC%0d: %0d * %0d",
                  test_num, A, B);
        $display("      got = %0d", product);
        $display(" expected = %0d", expected);
        fail_count = fail_count + 1;
      end

      repeat(2) @(posedge clk);
    end
  endtask

  // MAIN
  initial begin
    pass_count = 0;
    fail_count = 0;

    reset = 1;
    start = 0;

    repeat(2) @(posedge clk);
    reset = 0;

    $display("==== TEST START ====");
    
    run_test(13, 11, 143, 1);
    run_test(8, -7, -56, 2);
    run_test(-5, 6, -30, 3);
    run_test(-9, -4, 36, 4);
    run_test(999, 0, 0, 5);
    run_test(42, 1, 42, 6);
    run_test(100, -1, -100, 7);
    run_test(65535, 65535, 4294836225, 8);
    run_test(3, 8, 24, 9);

    $display("==== RESULT ====");
    $display("PASS: %0d", pass_count);
    $display("FAIL: %0d", fail_count);

    $finish;
  end

endmodule