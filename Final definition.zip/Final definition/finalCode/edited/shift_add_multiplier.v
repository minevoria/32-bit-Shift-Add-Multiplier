
module shift_add_multiplier_fsm (
    input  wire        clk,
    input  wire        reset,   // asynchronous reset, active high
    input  wire        start,

    input  wire signed [31:0] multiplicand,
    input  wire signed [31:0] multiplier,

    output reg  signed [63:0] product,
    output reg                done
);

  // ── Datapath registers ──
  reg [63:0] A;      
  reg [31:0] B;      
  reg [5:0]  count;  
  reg        sign;  

  //FSM states
  localparam IDLE    = 2'b00;
  localparam LOAD    = 2'b01;
  localparam COMPUTE = 2'b10;
  localparam DONE    = 2'b11;

  reg [1:0] state;

  //FSM + datapath (asynchronous reset)
  always @(posedge clk or posedge reset) begin

    if (reset) begin
      state   <= IDLE;
      A       <= 0;
      B       <= 0;
      product <= 0;
      count   <= 0;
      done    <= 0;
      sign    <= 0;
    end

    else begin
      case (state)

        IDLE: begin
          done <= 0;
          if (start)
            state <= LOAD;
        end

        LOAD: begin
          sign <= multiplicand[31] ^ multiplier[31];

          // If negative, negate to get absolute value; else use as-is.
          // Zero-extend into 64 bits so A can shift left 32 times.
          A <= multiplicand[31]
               ? {32'b0, -multiplicand}
               : {32'b0,  multiplicand};

          B <= multiplier[31]
               ? -multiplier
               : multiplier;

          product <= 0;
          count   <= 32;
          state   <= COMPUTE;
        end

        COMPUTE: begin
          if (B[0])
            product <= product + A; 
          A <= A << 1;         
          B <= B >> 1;           
          count <= count - 1;

          if (count == 1)
            state <= DONE;
        end

        DONE: begin
          if (sign)
            product <= -product; 
          done  <= 1;
          state <= IDLE;
        end

        default: state <= IDLE;

      endcase
    end
  end

endmodule
